let loggedIn = false;
const customizeBtn = document.getElementById("customizeBtn");
const themeSidebar = document.getElementById("themeSidebar");
const closeThemeSidebar = document.getElementById("closeThemeSidebar");
const mainContent = document.getElementById("mainContent");
const themeOptions = document.querySelectorAll(".theme-option");
const logoutPopup = document.getElementById("logoutPopup");
const loginPopup = document.getElementById("loginPopup");
const profile = document.getElementById("profileContainer");
const userIcon = document.getElementById("userIcon");
const profilePic = document.getElementById("profilePic");
const loginBtn = document.getElementById("loginBtn");
const logoutBtn = document.getElementById("logoutBtn");
customizeBtn.addEventListener("click", () => {
  themeSidebar.classList.add("show");
  mainContent.classList.add("shrink");
});
closeThemeSidebar.addEventListener("click", () => {
  themeSidebar.classList.remove("show");
  mainContent.classList.remove("shrink");
});
document.addEventListener("click", (event) => {
  if (!themeSidebar.contains(event.target) && !customizeBtn.contains(event.target)) {
    themeSidebar.classList.remove("show");
    mainContent.classList.remove("shrink");
  }
});
profile.addEventListener("click", (event) => {
  event.stopPropagation();
  if (!loggedIn) {
    loginPopup.classList.toggle("show");
    logoutPopup.classList.remove("show");
  } else {
    logoutPopup.classList.toggle("show");
    loginPopup.classList.remove("show");
  }
});
document.addEventListener("click", (event) => {
  if (!profile.contains(event.target)) {
    logoutPopup.classList.remove("show");
    loginPopup.classList.remove("show");
  }
});
loginBtn.addEventListener("click", () => {
  loggedIn = true;
  userIcon.classList.add("hide");
  profilePic.classList.remove("hide");
  loginPopup.classList.remove("show");
});
logoutBtn.addEventListener("click", () => {
  loggedIn = false;
  userIcon.classList.remove("hide");
  profilePic.classList.add("hide");
  logoutPopup.classList.remove("show");
});
function applyTheme(theme) {
  if (theme === "dark") {
    document.body.classList.add("dark-mode");
    document.body.classList.remove("light-mode");
  } else if (theme === "light") {
    document.body.classList.add("light-mode");
    document.body.classList.remove("dark-mode");
  } else {
    if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
      document.body.classList.add("dark-mode");
      document.body.classList.remove("light-mode");
    } else {
      document.body.classList.add("light-mode");
      document.body.classList.remove("dark-mode");
    }
  }
  localStorage.setItem("selectedTheme", theme);
  themeOptions.forEach((btn) => btn.classList.remove("selected"));
  const selectedBtn = document.getElementById(`${theme}Theme`);
  if (selectedBtn) {
    selectedBtn.classList.add("selected");
  }
}
const savedTheme = localStorage.getItem("selectedTheme") || "system";
applyTheme(savedTheme);
document.getElementById("systemTheme").addEventListener("click", () => applyTheme("system"));
document.getElementById("darkTheme").addEventListener("click", () => applyTheme("dark"));
document.getElementById("lightTheme").addEventListener("click", () => applyTheme("light"));
